//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by key_macro.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDS_ABOUTBOX                    101
#define IDD_KEY_MACRO_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_ADD_KEY              129
#define IDD_DIALOG_ADD_DELAY            130
#define IDD_DIALOG_ADD_MOUSE            131
#define IDD_DIALOG_MACRO_EDIT           132
#define IDD_DIALOG_MACRO_REC            133
#define IDC_LIST_MACROS                 1000
#define IDC_LIST_MACROS2                1001
#define IDC_LIST_ITEMS                  1003
#define IDC_BUTTON_ADD_KEY              1004
#define IDC_BUTTON_ADD_MOUSE            1005
#define IDC_EDIT_DELAY                  1006
#define IDC_BUTTON_ADD_DELAY            1007
#define IDC_BUTTON_DELETE               1008
#define IDC_RADIO_KEY_3                 1009
#define IDC_BUTTON_ADD_MACRO            1010
#define IDC_RADIO_KEY_1                 1011
#define IDC_BUTTON_DELETE_MACRO         1012
#define IDC_RADIO_KEY_2                 1013
#define IDC_BUTTON_EDIT                 1014
#define IDC_BUTTON_EDIT_MACRO           1015
#define IDC_CHECK_ABSPOS                1016
#define IDC_CHECK_REC_KEY               1017
#define IDC_CHECK_START_OPTION          1018
#define IDC_CHECK_WHEEL                 1019
#define IDC_BUTTON_MACRO_FILE           1020
#define IDC_CHECK_REC_MOUSE             1021
#define IDC_CHECK_STOP_OPTION           1022
#define IDC_EDIT_CURPOS_X               1023
#define IDC_EDIT_MACRO_FILE             1024
#define IDC_CHECK_REC_MOUSE_POS         1025
#define IDC_EDIT_MACRO_REPEAT_COUNT     1026
#define IDC_RADIO_MACRO_RUN             1027
#define IDC_EDIT_CURPOS_Y               1028
#define IDC_CHECK_TIME                  1029
#define IDC_RADIO_MACRO_EDIT            1030
#define IDC_RADIO_BUTTON_UP             1031
#define IDC_BUTTON_UP                   1032
#define IDC_CHECK_REC_MOUSE_WHEEL       1033
#define IDC_COMBO_KEYBOARD              1034
#define IDC_BUTTON_REC_MACRO            1035
#define IDC_BUTTON_DOWN                 1036
#define IDC_CHECK_MERGE                 1037
#define IDC_COMBO_MACRO_STOP            1038
#define IDC_EDIT_EVENT_MIN_DELAY        1039
#define IDC_COMBO_MACRO_START           1040
#define IDC_BUTTON_COPY_MACRO           1041
#define IDC_EDIT_MACRO_NAME             1042
#define IDC_COMBO_KEY                   1043
#define IDC_BUTTON_SAVE                 1046
#define IDC_RADIO_BUTTON_CLICK          1047
#define IDC_RADIO_BUTTON_DOWN           1048
#define IDC_EDIT_ABSPOS_X               1049
#define IDC_EDIT_ABSPOS_Y               1050
#define IDC_EDIT_TIME                   1051
#define IDC_EDIT_MOVE                   1052
#define IDC_EDIT_WHEEL                  1053
#define IDC_CHECK_REC_STAT              1054
#define IDC_STATIC_VERSION              1054
#define IDC_STATIC_REC_COUNT            1055
#define IDC_COMBO_BUTTON_SELECT         1056
#define IDC_STATIC_HOMEPAGE             1056
#define IDB_QUIT                        1058
#define IDC_BUTTON_QUIT                 1058
#define IDC_CHECK1                      1059
#define IDC_CHECK_HANGUL                1059
#define IDC_CHECK_IME_HAN_ENG           1059
#define IDC_CHECK_IME_HAN_ENG2          1060
#define IDC_CHECK_RELEASE_ALL_KEY       1060

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1060
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
