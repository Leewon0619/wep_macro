#pragma once

extern void LoadMacros (const char *macroFileName);
extern void SaveMacro  (const char *macroFileName);

