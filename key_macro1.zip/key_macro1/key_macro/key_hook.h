#pragma once

extern void OnRawKeyboard (RAWKEYBOARD &keyboard);
extern void OnRawMouse (RAWMOUSE &mouse);
